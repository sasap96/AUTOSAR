#if !defined(VTTSYSVARS_H)
#define VTTSYSVARS_H

#include "VttCntrl.h"

extern sint32 handle_lightOnOffCounter;
extern sint32 handle_odometer;
extern sint32 handle_odometerWriteReqPending;

#endif
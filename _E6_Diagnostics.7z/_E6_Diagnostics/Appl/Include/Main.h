
#if !defined(MAIN_H)
#define MAIN_H


void BswInitListOne(void);
void CANoeAPI_Main(void);
void BswNvMReadAll(void);

void main(void);

#endif